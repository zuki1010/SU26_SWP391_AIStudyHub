package swp391.aistudyhub.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import swp391.aistudyhub.dto.projection.UserAccountResponse;
import swp391.aistudyhub.enums.AccountStatus;
import swp391.aistudyhub.enums.UserRole;
import swp391.aistudyhub.service.AdminService;
import swp391.aistudyhub.service.UserService;

import java.util.UUID;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin("*")
@Tag(name = "Admin Dashboard", description = "View User Account, View Document List")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/account")
    public ResponseEntity<Page<UserAccountResponse>> getAllUser(@RequestParam(required = false) String key,
                                                                @RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok().body(adminService.getAllCustomer(key, page, size));
    }

    @PutMapping("/account/status/{id}")
    public ResponseEntity<?> updateUserStatus(@PathVariable("id") UUID userId,
                                              @RequestParam AccountStatus status) {
        return ResponseEntity.ok().body(adminService.updateUserStatus(userId, status));
    }

    @GetMapping("/document")
    public ResponseEntity<?> getAllDocument(@RequestParam(defaultValue = "0") int page,
                                                     @RequestParam(defaultValue = "10") int size
    ) {
        return ResponseEntity.ok().body(adminService.getAllDocument(page, size));
    }

    @PutMapping("/account/role/{id}")
    public ResponseEntity<?> updateUserRole(@PathVariable("id") UUID userId,
                                            @RequestParam UserRole role) {
        return ResponseEntity.ok(adminService.updateUserRole(userId, role));
    }

    @GetMapping("/chat")
    public ResponseEntity<?> getAllChatToDay(@RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(adminService.getAllChat(page, size));
    }

    @GetMapping("/storage")
    public ResponseEntity<?> getAllStorageUsage(@RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(adminService.getAllStorage(page, size));
    }

    @PutMapping("/config-storage")
    public ResponseEntity<?> configureTotalStorageQuota() {
        return ResponseEntity.ok(null);
    }
    @PutMapping("/config-aitoken")
    public ResponseEntity<?> configureChatToken() {
        return ResponseEntity.ok(null);
    }
    @PutMapping("/config-file-size")
    public ResponseEntity<?> configureMaxFileSize() {
        return ResponseEntity.ok(null);
    }
    @PutMapping("/config-file-type")
    public ResponseEntity<?> configureAvailableFileType() {
        return ResponseEntity.ok(null);
    }
}
