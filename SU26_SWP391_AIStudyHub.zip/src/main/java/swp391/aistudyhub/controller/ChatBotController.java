package swp391.aistudyhub.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import swp391.aistudyhub.config.OpenApiConfig;
import swp391.aistudyhub.dto.request.ChatRequestSessionDTO;
import swp391.aistudyhub.dto.request.StartSessionDTO;
import swp391.aistudyhub.dto.response.ChatMessageDTO;
import swp391.aistudyhub.dto.response.UpdateSessionDocsDTO;
import swp391.aistudyhub.service.ChatBotService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/chat")
@Tag(name = "AI ChatBot", description = "Create session, chat")
@SecurityRequirement(name = OpenApiConfig.BEARER_SCHEME)
@PreAuthorize("hasAnyRole('CUSTOMER', 'MODERATOR')")
public class ChatBotController {

    @Autowired
    private ChatBotService chatBotService;

    @PostMapping("/start")
    public ResponseEntity<?> startChat(@RequestBody(required = false) UUID documentId) {
        UUID sessionId = chatBotService.createNewChatSession(documentId);
        return ResponseEntity.ok().body("Chat Session Created. Session ID: " + sessionId);
    }

    @PutMapping("/session/{sessionId}/documents")
    public ResponseEntity<?> updateDocuments(
            @PathVariable UUID sessionId,
            @RequestBody UUID documentId) {
        chatBotService.updateSessionDocuments(sessionId, documentId);
        return ResponseEntity.ok().body("Update Document Successfully!");
    }

    @PostMapping("/send-message")
    public ResponseEntity<String> sendMessage(@RequestBody ChatRequestSessionDTO dto) {
        if (dto.getSessionId() == null || dto.getMessageContent() == null || dto.getMessageContent().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("This field cannot be empty!");
        }

        try {
            String aiResponse = chatBotService.chatWithGemini(dto);

            return ResponseEntity.ok().body(aiResponse);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Chat Process Error: " + e.getMessage());
        }
    }

    @GetMapping("/session/{sessionId}/history")
    public ResponseEntity<List<ChatMessageDTO>> getChatHistory(
            @PathVariable UUID sessionId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        List<ChatMessageDTO> history = chatBotService.getChatHistory(sessionId, page, size);
        return ResponseEntity.ok(history);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteChat(@PathVariable("id") UUID sessionId) {
        chatBotService.deleteChat(sessionId);
        return ResponseEntity.ok("Xóa phiên chat thành công");
    }
}