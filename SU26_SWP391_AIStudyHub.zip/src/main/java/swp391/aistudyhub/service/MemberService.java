package swp391.aistudyhub.service;

public interface MemberService {
    void registerMember();

}
